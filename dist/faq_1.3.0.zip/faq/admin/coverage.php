<?php

require_once '../../../lib-common.php';

if (!SEC_hasRights('faq.admin,faq.edit', 'OR')) {
    $display = COM_showMessageText($LANG_FAQ_ADMIN['Access Denied MSG'], $LANG_FAQ_ADMIN['FAQ Plugin']);
    COM_output(COM_createHTMLDocument($display));
    exit;
}

$provider = isset($_GET['provider']) ? COM_applyFilter($_GET['provider']) : 'article';
if (!faq_relationProviderAllowed($provider)) {
    $provider = 'article';
}

$status = isset($_GET['status']) ? COM_applyFilter($_GET['status']) : 'all';

// Development compatibility with the first 1.3.0 Coverage filters.
if ($status === 'with') {
    $status = 'managed';
} elseif ($status === 'without') {
    $status = 'none';
}
if (!in_array($status, array('all', 'managed', 'external', 'both', 'none'), true)) {
    $status = 'all';
}

$limit = isset($_FAQ_CONF['coverage_limit']) ? (int) $_FAQ_CONF['coverage_limit'] : 100;
if ($limit < 1 || $limit > 200) {
    $limit = 100;
}

$coreAudit = in_array($provider, array('article', 'staticpages'), true);

if ($coreAudit) {
    // Core coverage is an audit, not a picker: inspect every accessible item.
    $limit = 0;
    // Geeklog Core and Static Pages do not yet expose the shared collection
    // surface required for this audit. Follow Hub's read-only Core-table audit
    // precedent rather than pretending the capability exists.
    $items = faq_coverageCoreCollection($provider, $limit);
} else {
    $items = faq_providerCollection($provider, 'id,title,url,date-modified', array(
        'limit' => $limit,
        'order' => 'modified-desc'
    ));
}

$_SCRIPTS->setCSSFile('faq_admin', faq_assetPath('faq-admin.css'));
$display = faq_adminNavigation('coverage');
$display .= COM_startBlock($LANG_FAQ_COVERAGE['title']);

$providerLabels = array(
    'article' => $LANG_FAQ_COVERAGE['articles'],
    'staticpages' => $LANG_FAQ_COVERAGE['static_pages'],
    'videos' => $LANG_FAQ_COVERAGE['videos'],
    'documents' => $LANG_FAQ_COVERAGE['documents'],
    'maps' => $LANG_FAQ_COVERAGE['maps'],
    'mediagallery' => $LANG_FAQ_COVERAGE['media_gallery']
);

$display .= '<form method="get" action="' . $_CONF['site_admin_url']
          . '/plugins/faq/coverage.php" class="faq-admin-toolbar">';
$display .= '<label for="faq-coverage-provider">'
          . htmlspecialchars($LANG_FAQ_COVERAGE['provider'], ENT_QUOTES, 'UTF-8')
          . '</label><select id="faq-coverage-provider" name="provider">';
foreach ($providerLabels as $key => $label) {
    $selected = $provider === $key ? ' selected' : '';
    $display .= '<option value="' . $key . '"' . $selected . '>'
              . htmlspecialchars($label, ENT_QUOTES, 'UTF-8') . '</option>';
}
$display .= '</select>';

$display .= '<label for="faq-coverage-status">'
          . htmlspecialchars($LANG_FAQ_COVERAGE['faq_status'], ENT_QUOTES, 'UTF-8')
          . '</label><select id="faq-coverage-status" name="status">'
          . '<option value="all"' . ($status === 'all' ? ' selected' : '') . '>'
          . htmlspecialchars($LANG_FAQ_COVERAGE['all'], ENT_QUOTES, 'UTF-8') . '</option>'
          . '<option value="managed"' . ($status === 'managed' ? ' selected' : '') . '>'
          . htmlspecialchars($LANG_FAQ_COVERAGE['managed_faq_only'], ENT_QUOTES, 'UTF-8') . '</option>'
          . '<option value="external"' . ($status === 'external' ? ' selected' : '') . '>'
          . htmlspecialchars($LANG_FAQ_COVERAGE['external_faq_only'], ENT_QUOTES, 'UTF-8') . '</option>'
          . '<option value="both"' . ($status === 'both' ? ' selected' : '') . '>'
          . htmlspecialchars($LANG_FAQ_COVERAGE['managed_external'], ENT_QUOTES, 'UTF-8') . '</option>'
          . '<option value="none"' . ($status === 'none' ? ' selected' : '') . '>'
          . htmlspecialchars($LANG_FAQ_COVERAGE['no_faq_detected'], ENT_QUOTES, 'UTF-8') . '</option>'
          . '</select><input type="submit" value="'
          . htmlspecialchars($LANG_FAQ_COVERAGE['show'], ENT_QUOTES, 'UTF-8') . '"></form>';

if ($items === false) {
    $display .= '<p>'
              . htmlspecialchars($LANG_FAQ_COVERAGE['provider_not_enumerable'], ENT_QUOTES, 'UTF-8')
              . '</p>';
} else {
    if ($coreAudit) {
        $display .= '<p class="faq-admin-audit-note"><strong>'
                  . htmlspecialchars($LANG_FAQ_COVERAGE['core_audit_label'], ENT_QUOTES, 'UTF-8')
                  . '</strong> '
                  . htmlspecialchars($LANG_FAQ_COVERAGE['core_audit_help'], ENT_QUOTES, 'UTF-8')
                  . '</p>';
    }

    $managedOnly = 0;
    $externalOnly = 0;
    $both = 0;
    $none = 0;
    $rows = '';

    foreach ($items as $item) {
        if (!is_array($item) || !isset($item['id'])) {
            continue;
        }

        $count = faq_relationCountForItem($provider, (string) $item['id']);
        $signals = array();
        if ($coreAudit && isset($item['_audit_content'])) {
            $signals = faq_coverageExternalSignals($item['_audit_content']);
        }

        $hasManaged = $count > 0;
        $hasExternal = !empty($signals);

        if ($hasManaged && $hasExternal) {
            $both++;
            $rowStatus = 'both';
        } elseif ($hasManaged) {
            $managedOnly++;
            $rowStatus = 'managed';
        } elseif ($hasExternal) {
            $externalOnly++;
            $rowStatus = 'external';
        } else {
            $none++;
            $rowStatus = 'none';
        }

        if ($status !== 'all' && $status !== $rowStatus) {
            continue;
        }

        $title = isset($item['title']) ? $item['title'] : $item['id'];
        $title = html_entity_decode((string) $title, ENT_QUOTES, 'UTF-8');
        $url = isset($item['url']) ? $item['url'] : '';
        $titleHtml = htmlspecialchars($title, ENT_QUOTES, 'UTF-8');
        if ($url !== '') {
            $titleHtml = '<a href="' . htmlspecialchars($url, ENT_QUOTES, 'UTF-8') . '">'
                       . $titleHtml . '</a>';
        }

        $signalHtml = empty($signals)
            ? '&mdash;'
            : htmlspecialchars(implode(', ', $signals), ENT_QUOTES, 'UTF-8');

        $stateLabel = $rowStatus === 'both'
            ? $LANG_FAQ_COVERAGE['managed_external']
            : ($rowStatus === 'managed'
                ? $LANG_FAQ_COVERAGE['managed']
                : ($rowStatus === 'external'
                    ? $LANG_FAQ_COVERAGE['external_signal']
                    : $LANG_FAQ_COVERAGE['none']));

        $actions = '<a href="' . $_CONF['site_admin_url']
                 . '/plugins/faq/relations.php?provider=' . rawurlencode($provider)
                 . '&amp;item_id=' . rawurlencode((string) $item['id']) . '">'
                 . htmlspecialchars($LANG_FAQ_COVERAGE['manage'], ENT_QUOTES, 'UTF-8')
                 . '</a>';

        if ($provider === 'article') {
            $actions .= ' &middot; <a href="' . $_CONF['site_admin_url']
                     . '/story.php?mode=edit&amp;sid='
                     . rawurlencode((string) $item['id']) . '">'
                     . htmlspecialchars($LANG_FAQ_COVERAGE['edit'], ENT_QUOTES, 'UTF-8') . '</a>';
        } elseif ($provider === 'staticpages') {
            $actions .= ' &middot; <a href="' . $_CONF['site_admin_url']
                     . '/plugins/staticpages/index.php?mode=edit&amp;sp_id='
                     . rawurlencode((string) $item['id']) . '">'
                     . htmlspecialchars($LANG_FAQ_COVERAGE['edit'], ENT_QUOTES, 'UTF-8') . '</a>';
        }

        $rows .= '<tr><td>' . $titleHtml . '<br><small>'
               . htmlspecialchars((string) $item['id'], ENT_QUOTES, 'UTF-8') . '</small></td>';
        $rows .= '<td><strong>' . htmlspecialchars($stateLabel, ENT_QUOTES, 'UTF-8')
               . '</strong><br><small>'
               . htmlspecialchars($LANG_FAQ_COVERAGE['managed_relations'], ENT_QUOTES, 'UTF-8')
               . ' ' . $count . '</small></td>';
        $rows .= '<td>' . $signalHtml . '</td>';
        $rows .= '<td>' . $actions . '</td></tr>';
    }

    $baseCoverageUrl = $_CONF['site_admin_url']
        . '/plugins/faq/coverage.php?provider=' . rawurlencode($provider);
    $total = $managedOnly + $externalOnly + $both + $none;

    $summary = array(
        'managed' => array($managedOnly, $LANG_FAQ_COVERAGE['managed_only']),
        'external' => array($externalOnly, $LANG_FAQ_COVERAGE['external_only']),
        'both' => array($both, $LANG_FAQ_COVERAGE['both']),
        'none' => array($none, $LANG_FAQ_COVERAGE['none']),
        'all' => array($total, $LANG_FAQ_COVERAGE['all'])
    );

    $display .= '<div class="faq-admin-summary">';
    foreach ($summary as $summaryKey => $summaryData) {
        $display .= '<a class="faq-admin-summary-link'
                  . ($status === $summaryKey ? ' active' : '')
                  . '" href="'
                  . htmlspecialchars($baseCoverageUrl . '&status=' . $summaryKey, ENT_QUOTES, 'UTF-8')
                  . '"><strong>' . (int) $summaryData[0] . '</strong>'
                  . htmlspecialchars($summaryData[1], ENT_QUOTES, 'UTF-8') . '</a>';
    }
    $display .= '</div>';

    $display .= '<div class="faq-admin-table"><table class="admin-list"><thead><tr>'
              . '<th>' . htmlspecialchars($LANG_FAQ_COVERAGE['content'], ENT_QUOTES, 'UTF-8') . '</th>'
              . '<th>' . htmlspecialchars($LANG_FAQ_COVERAGE['faq_status'], ENT_QUOTES, 'UTF-8') . '</th>'
              . '<th>' . htmlspecialchars($LANG_FAQ_COVERAGE['external_signals'], ENT_QUOTES, 'UTF-8') . '</th>'
              . '<th>' . htmlspecialchars($LANG_FAQ_COVERAGE['action'], ENT_QUOTES, 'UTF-8') . '</th>'
              . '</tr></thead><tbody>' . $rows . '</tbody></table></div>';
}

$display .= COM_endBlock();

COM_output(COM_createHTMLDocument(
    $display,
    array('pagetitle' => $LANG_FAQ_COVERAGE['title'])
));
